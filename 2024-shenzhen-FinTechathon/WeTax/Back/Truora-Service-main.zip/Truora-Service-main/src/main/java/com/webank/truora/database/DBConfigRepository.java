package com.webank.truora.database;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 */


public interface DBConfigRepository extends JpaRepository<DBConfig, Long> {

}